import mineflayer from "mineflayer";
import { logger } from "./lib/logger";

const HOST = "accentsmp.aternos.me";
const PORT = 32424;
const USERNAME = "Accent_Bot_247";
const VERSION = "1.21";

let bot: ReturnType<typeof mineflayer.createBot> | null = null;
let reconnectTimer: ReturnType<typeof setTimeout> | null = null;
let jumpTimer: ReturnType<typeof setInterval> | null = null;

function clearTimers() {
  if (reconnectTimer) {
    clearTimeout(reconnectTimer);
    reconnectTimer = null;
  }
  if (jumpTimer) {
    clearInterval(jumpTimer);
    jumpTimer = null;
  }
}

function createBot() {
  clearTimers();

  logger.info({ host: HOST, port: PORT, username: USERNAME }, "Connecting to Minecraft server");

  bot = mineflayer.createBot({
    host: HOST,
    port: PORT,
    username: USERNAME,
    version: VERSION,
    auth: "offline",
  });

  bot.once("spawn", () => {
    logger.info("Bot spawned, waiting 5 seconds before sending login commands");

    setTimeout(() => {
      if (!bot) return;
      bot.chat("/register Accent247 Accent247");
      logger.info("Sent /register command");

      setTimeout(() => {
        if (!bot) return;
        bot.chat("/login Accent247");
        logger.info("Sent /login command");
      }, 1000);
    }, 5000);

    jumpTimer = setInterval(() => {
      if (!bot) return;
      bot.setControlState("jump", true);
      setTimeout(() => {
        if (!bot) return;
        bot.setControlState("jump", false);
      }, 200);
      logger.info("Bot jumped to prevent AFK kick");
    }, 15000);
  });

  bot.on("chat", (username: string, message: string) => {
    logger.info({ username, message }, "Chat message received");
  });

  bot.on("kicked", (reason: string) => {
    logger.warn({ reason }, "Bot was kicked, scheduling reconnect in 10 seconds");
    clearTimers();
    reconnectTimer = setTimeout(createBot, 10000);
  });

  bot.on("error", (err: Error) => {
    logger.error({ err: err.message }, "Bot encountered an error");
  });

  bot.on("end", (reason: string) => {
    logger.warn({ reason }, "Bot disconnected, scheduling reconnect in 10 seconds");
    clearTimers();
    reconnectTimer = setTimeout(createBot, 10000);
  });
}

export function startBot() {
  createBot();
}
