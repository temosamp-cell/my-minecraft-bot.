import express, { type Express } from "express";
import cors from "cors";
import pinoHttp from "pino-http";
import router from "./routes";
import { logger } from "./lib/logger";

const app: Express = express();

app.use(
  pinoHttp({
    logger,
    serializers: {
      req(req) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use("/api", router);

app.get("/", (_req, res) => {
  res.send(`<!DOCTYPE html><html><head><title>Bot Status</title></head><body>
    <h2>Accent_Bot_247 — Online</h2>
    <p>Minecraft AFK bot is running.</p>
    <p>Health check: <a href="/api/healthz">/api/healthz</a></p>
  </body></html>`);
});

app.get("/healthz", (_req, res) => {
  res.json({ status: "ok" });
});

export default app;
